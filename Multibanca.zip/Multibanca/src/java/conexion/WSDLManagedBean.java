/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexion;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author luthor corp
 */
@ManagedBean
@SessionScoped
public class WSDLManagedBean {

    /**
     * Creates a new instance of WSDLManagedBean
     */
    public WSDLManagedBean() {
    }
    
}
